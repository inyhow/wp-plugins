﻿<?php
/**
 * Plugin Name: Statistics Plugin
 * Plugin URI: https://www.vm88.top/statistics-plugin
 * Description: 根据指定位置，添加页头或页尾统计代码。
 * Version: 1.0.0
 * Author: inyhow
 * Author URI: https://www.vm88.top
 */

// 添加设置链接
add_filter('plugin_action_links', 'statistics_plugin_settings_link', 10, 2);

function statistics_plugin_settings_link($links, $file) {
    if ($file === plugin_basename(__FILE__)) {
        $settings_link = '<a href="' . admin_url('options-general.php?page=statistics-plugin-settings') . '">设置</a>';
        array_unshift($links, $settings_link);
    }
    return $links;
}

// 插入统计代码
function insert_statistics_code() {
    $statistics_code_head = get_option('statistics_code_head');
    $statistics_code_body = get_option('statistics_code_body');

    if (!is_admin()) {
        if (!empty($statistics_code_head)) {
            add_action('wp_head', function() use ($statistics_code_head) {
                echo $statistics_code_head;
            });
        }

        if (!empty($statistics_code_body)) {
            add_action('wp_footer', function() use ($statistics_code_body) {
                echo $statistics_code_body;
            }, 9999); // 设置优先级为9999，确保在</body>标签之前输出
        }
    }
}
add_action('wp_loaded', 'insert_statistics_code');

// 设置页面
add_action('admin_menu', 'statistics_plugin_settings_page');

function statistics_plugin_settings_page() {
    add_options_page(
        '统计代码设置',
        '统计代码',
        'manage_options',
        'statistics-plugin-settings',
        'statistics_plugin_settings'
    );
}

function statistics_plugin_settings() {
    if (!current_user_can('manage_options')) {
        wp_die('无权访问此页面');
    }

    ?>
    <div class="wrap">
        <h1>统计代码设置</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('statistics_plugin_settings');
            do_settings_sections('statistics_plugin_settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// 注册设置
add_action('admin_init', 'statistics_plugin_settings_init');

function statistics_plugin_settings_init() {
    register_setting('statistics_plugin_settings', 'statistics_code_head');
    register_setting('statistics_plugin_settings', 'statistics_code_body');

    add_settings_section(
        'statistics_plugin_settings_section',
        '统计代码设置',
        '',
        'statistics_plugin_settings'
    );

    add_settings_field(
        'statistics_code_head',
        'Head 统计代码',
        'statistics_code_head_field',
        'statistics_plugin_settings',
        'statistics_plugin_settings_section'
    );

    add_settings_field(
        'statistics_code_body',
        'Body 统计代码',
        'statistics_code_body_field',
        'statistics_plugin_settings',
        'statistics_plugin_settings_section'
    );
}

function statistics_code_head_field() {
    $statistics_code_head = get_option('statistics_code_head');
    echo '<textarea name="statistics_code_head" rows="5" cols="50">' . esc_textarea($statistics_code_head) . '</textarea>';
}

function statistics_code_body_field() {
    $statistics_code_body = get_option('statistics_code_body');
    echo '<textarea name="statistics_code_body" rows="5" cols="50">' . esc_textarea($statistics_code_body) . '</textarea>';
}
