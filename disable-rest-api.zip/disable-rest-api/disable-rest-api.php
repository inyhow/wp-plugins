<?php
/*
Plugin Name: Disable REST API, Feeds, and XML-RPC
Description: Disables the WordPress REST API, all RSS/Atom/RDF feeds, and XML-RPC.
Version: 1.3
Author: inyhow
Author URI: https://www.vm88.top
*/

// Disable REST API
add_filter('rest_authentication_errors', 'disable_rest_api');

function disable_rest_api($access) {
    if (!is_user_logged_in()) {
        // If the user is not logged in, return a permission denied error
        return new WP_Error('rest_forbidden', __('REST API is disabled.'), array('status' => 403));
    }
    return $access;
}

// Disable RSS/Atom/RDF feeds
add_action('do_feed', 'disable_feeds', 1);
add_action('do_feed_rdf', 'disable_feeds', 1);
add_action('do_feed_rss', 'disable_feeds', 1);
add_action('do_feed_rss2', 'disable_feeds', 1);
add_action('do_feed_atom', 'disable_feeds', 1);

function disable_feeds() {
    wp_die(__('RSS/Atom/RDF feeds are disabled.'));
}

// Disable XML-RPC
add_filter('xmlrpc_enabled', '__return_false');

// Plugin settings
add_action('admin_menu', 'disable_plugin_options_menu');

function disable_plugin_options_menu() {
    add_options_page('Disable Plugin Settings', 'Disable Plugin', 'manage_options', 'disable-plugin-settings', 'disable_plugin_options_page');
}

function disable_plugin_options_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }

    if (isset($_POST['disable_plugin_submit'])) {
        update_option('disable_plugin_powered_by', sanitize_text_field($_POST['disable_plugin_powered_by']));
        echo '<div id="setting-error-settings_updated" class="updated settings-error"><p><strong>Power By information has been updated.</strong></p></div>';
    }

    $powered_by = get_option('disable_plugin_powered_by');
    ?>
    <div class="wrap">
        <h1>Disable Plugin Settings</h1>
        <form method="post" action="">
            <table class="form-table">
                <tr>
                    <th scope="row">Power By</th>
                    <td>
                        <input type="text" name="disable_plugin_powered_by" value="<?php echo esc_attr($powered_by); ?>" class="regular-text" />
                    </td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="disable_plugin_submit" class="button-primary" value="Save Changes" />
            </p>
        </form>
    </div>
    <?php
}

// Modify "Powered By" text in footer
add_filter('admin_footer_text', 'disable_plugin_modify_footer_text', 9999);
add_filter('update_footer', 'disable_plugin_modify_footer_text', 9999);

function disable_plugin_modify_footer_text($text) {
    $powered_by = get_option('disable_plugin_powered_by');
    if (!empty($powered_by)) {
        return 'Powered by ' . esc_html($powered_by);
    }
    return $text;
}
