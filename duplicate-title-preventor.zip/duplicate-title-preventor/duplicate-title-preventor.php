<?php
/*
Plugin Name: Duplicate Title Preventor
Plugin URI: https://www.vm88.top/
Description: Prevents duplicate post titles and disallows saving as draft.
Version: 1.0
Author: inyhow
Author URI: https://www.vm88.top/
License: GPL2
*/

// 在文章发布前检测标题是否重复并禁止保存为草稿
function check_duplicate_title($data, $postarr) {
    $post_title = $data['post_title'];
    $post_type = $data['post_type'];
    $post_status = $data['post_status'];

    // 检查是否为文章类型和发布状态
    if ($post_type === 'post' && $post_status === 'publish') {
        // 检查重复标题
        $args = array(
            'post_type' => 'post',
            'post_status' => array('publish', 'draft'), // 包括发布和草稿状态
            'posts_per_page' => -1,
            'fields' => 'ids',
            'post_title' => $post_title
        );

        $query = new WP_Query($args);

        // 排除当前文章自身
        if (isset($postarr['ID'])) {
            $args['post__not_in'] = array($postarr['ID']);
        }

        // 如果找到重复标题的文章，阻止发布并显示错误消息
        if ($query->have_posts()) {
            wp_die('Duplicate title. This post cannot be published.');
        }
    } elseif ($post_type === 'post' && $post_status === 'draft') {
        // 如果文章类型为'post'且状态为草稿，禁止保存为草稿
        wp_die('Saving as draft is not allowed for this post type.');
    }

    return $data;
}
add_filter('wp_insert_post_data', 'check_duplicate_title', 10, 2);
